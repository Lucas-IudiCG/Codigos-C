#include <iostream>
#include "VetorCH.h"
//Lucas Iudi Corregliano Gallinari
//M�tricula: 32138628
//Turma 3G
//"Materia: Estrutura de Dados I
//"Professor: Andr� Kishimoto

int main(){
setlocale(LC_CTYPE,"Portuguese");//define o idioma para portugues
bool Menu=false;

Queue F1=Create();//cria a estrutura Queue, chamada F1
PrintFrontCountSize(F1);
char nada;
 std::cout << "--------------------\n";
 std::cout<<"Digite qualquer character para iniciar os processos de Enqueue: ";//usei esse std::cin, apenas para demorar e para voc~e e eu poder conferir o que foi printado por etapas
 std::cin>>nada;
 std::string str = "Queue Hello, World!";//quebra a string hello world e coloca seus respectivos elementos ao long da fila
 for (int i = 0; i < str.length(); ++i)
 {
 if (!Enqueue(F1, str[i]))
 std::cout << "Fila cheia! N�o foi poss�vel inserir " << str[i] << '\n';
 PrintFrontCountSize(F1);

}
std::cout << "--------------------\n";
    std::cout<<"Digite qualquer character para iniciar os processos de Dequeue: ";//usei esse std::cin, apenas para demorar e para voc~e e eu poder conferir o que foi printado por etapas
    std::cin>>nada;
char Fronte;
while (!IsEmpty(F1))//vai retirando os elementos da fila seguindo a ordem de espera, e com metodo vetor circular
 {
 Fronte = Dequeue(F1);
 std::cout << "Dequeue retornou: " << Fronte << '\n';
 PrintFrontCountSize(F1);
 }
 std::cout << "--------------------\n";
    std::cout<<"Digite qualquer character para iniciar a Tabela de Comandos: ";//usei esse std::cin, apenas para demorar e para voc~e e eu poder conferir o que foi printado por etapas
    std::cin>>nada;
 for (const char& c : str)//adiciona de novo o ultimo elemento da string, no caso "!"
 {
 if (!Enqueue(F1, c))
 std::cout << "Fila cheia! N�o foi poss�vel inserir " << c << '\n';
 }
 PrintFrontCountSize(F1);
 std::cout << "--------------------\n";
 Clear(F1);//da um clear direto.
 PrintFrontCountSize(F1);
    Comands();//come�a a tabela de comando feita para testar as fun��es.
while (Menu==false){
int Comando;
std::cout<<"Comando: ";
std::cin>>Comando;

if(Comando==0){//se comando = 0, os comandos s�o impridos denovo.
    Comands();
}

if(Comando==1){//se comando = 1, � printado todos os elementos da fila
    Print(F1);
}
if(Comando==2){//se comando = 2,adiciona um elemento na fila
    char Valor;
    std::cout<<"Adicionar elemento na fila: ";
    std::cin>>Valor;
    Enqueue(F1,Valor);
}
if(Comando==3){//se comando = 3,retira um elemento da fila
    char RMV=Dequeue(F1);
    if(RMV!=NULL){
    std::cout<<"Elemento removido: "<<RMV<<"\n";
}
    else{
    std::cout<<"Elemento Vazio\n";
    }
}
if(Comando==4){//se comando = 4,imprime o topo junto com a capacidade da fila
    char Frente=Front(F1);
    std::cout<<"Frente: "<<Frente<<"\n";
}
if(Comando==5){//se comando = 5,retorna ainda quantos elementos podem ser adicionados
    int Cap=Size(F1);
    int Tam=Count(F1);
    std::cout<<"Elementos na fila: "<<Cap-Tam<<"\n";
}
if(Comando==6){
    int Quant=Size(F1);
    std::cout<<"Tamanho: "<<Quant<<"\n";
}
if(Comando==7){//se comando = 6, quantos elementos est�o na fila
    bool Vazio=IsEmpty(F1);
}
if(Comando==8){//se comando = 7, retorna um variavel bool, que confirma se est� vazia ou n�o
    Clear(F1);
    std::cout<<"fila Esvaziada\n";
}
if(Comando==8){//se comando = 8,Esvazia a fila
    Clear(F1);
    std::cout<<"fila Esvaziada\n";
}
if(Comando==9){//se comando = 9,imprime os creditos
    Credits();
}

if(Comando==10){//se comando = 10,o menu vira true,tirando do loop,finalizando o programa
    Menu=true;
    std::cout<<"Programa Finalizado";
}
if(Comando==-1){//se comando = -1,ele repete o teste do codigo
char nada;
 std::cout << "--------------------\n";
 std::cout<<"Digite qualquer character para iniciar os processos de Enqueue: ";//usei esse std::cin, apenas para demorar e para voc~e e eu poder conferir o que foi printado por etapas
 std::cin>>nada;
 std::string str = "Queue Hello, World!";
 for (int i = 0; i < str.length(); ++i)
 {
 if (!Enqueue(F1, str[i]))
 std::cout << "Fila cheia! N�o foi poss�vel inserir " << str[i] << '\n';
 PrintFrontCountSize(F1);

}
std::cout << "--------------------\n";
    std::cout<<"Digite qualquer character para iniciar os processos de Dequeue: ";//usei esse std::cin, apenas para demorar e para voc~e e eu poder conferir o que foi printado por etapas
    std::cin>>nada;
char Fronte;
while (!IsEmpty(F1))
 {
 Fronte = Dequeue(F1);
 std::cout << "Dequeue retornou: " << Fronte << '\n';
 PrintFrontCountSize(F1);
 }
 std::cout << "--------------------\n";
    std::cout<<"Digite qualquer character para iniciar a Tabela de Comandos: ";//usei esse std::cin, apenas para demorar e para voc~e e eu poder conferir o que foi printado por etapas
    std::cin>>nada;
 for (const char& c : str)
 {
 if (!Enqueue(F1, c))
 std::cout << "Fila cheia! N�o foi poss�vel inserir " << c << '\n';
 }
 PrintFrontCountSize(F1);
 std::cout << "--------------------\n";
 Clear(F1);
 PrintFrontCountSize(F1);
}
}

return 0;
}
