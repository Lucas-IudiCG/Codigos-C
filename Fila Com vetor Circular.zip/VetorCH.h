#ifndef VETORCH_H_INCLUDED
#define VETORCH_H_INCLUDED

//Lucas Iudi Corregliano Gallinari
//M�tricula: 32138628
//Turma 3G
//"Materia: Estrutura de Dados I
//"Professor: Andr� Kishimoto

//para mexer com estruturas e como deve ser utilizado eu utilizei principalmente como base o codigo que mostrava o Struct Student apresentado em aula
const int n=16;//define como constante a variavel (int) chamada n, que  posteriormente ser� usada para determinar o tamanho do array

struct Queue{//cria um estratura chamada "Queue", que cont�m um char array[n],junto com int(Front,Rear,Count), que determina os elementos do vetor circular
    char Arr[n];
    int Front;
    int Rear;
    int Count;
};

Queue Create()//cria e retorna uma fila baseado na estrutura acima
{
    Queue fila ={{},0,0};
    return fila;
    //o restos das duvidas com struct,eu achei no link abaixo:
    // https://docs.microsoft.com/pt-br/cpp/cpp/struct-cpp?view=msvc-170
}
bool Enqueue(Queue &fila,char value){//encaixa um novo elemento na fila, baseado no Rear, e se cabe baseado no Count
    int R=fila.Rear;
    int C=fila.Count;
    if (C<16){
        fila.Arr[R]=value;
        ++R;
        int Y=R%n;
        fila.Rear =Y;
        ++C;
        fila.Count=C;
        return true;
    }
    else{
        return false;
    }
}

int Dequeue(Queue &fila){//pega o elemento da posi��o fila.Front e o utiliza para remover o proximo elemento da fila
    int F=fila.Front;
    int C=fila.Count;
    if(C==0){
       return NULL;
    }
    else{
       char RMV=fila.Arr[F];
       fila.Arr[F]=NULL;
       ++F;
       --C;
       int Y=F%n;
       fila.Front=Y;
       fila.Count=C;
       return RMV;
    }
}

char Front(Queue &fila){//determina qual � o proximo elemento a ser retirado e o informa, baseado no fila.Front
    char Frente;
    Frente=fila.Arr[fila.Front];
    return Frente;
}

int Count(Queue &fila){//retorna o n�meros de elementos na fila.count
    int Quant=fila.Count;
    return Quant;
}

int Size(Queue &fila){//retorna o tamanho da fila: 16
    int Tamanho=16;
    return Tamanho;
}

bool IsEmpty(Queue &fila){//verifica de a fila tem elementos ,baseado no fila.Count,se o elemento 0, for nulo, ent�o todos s�o, retornando true, se n�o, false
    bool Vazio;
    if (fila.Count==NULL){
        return true;
    }
    else{
        return false;
    }
}

void Clear(Queue &fila){//ele substitui todos os elementos da fila por NULL indiscriminadamente
    for(int i=0;i<n;++i){
        fila.Arr[i]=NULL;
    }
    fila.Front=0;
    fila.Rear=0;
    fila.Count=0;
}

void Print(Queue &fila){//apenas uma maneira pratica e direta de verificar todos os elementos da fila
    std::cout<<"> Representa o Front(Posi��o do proximo elemento a ser retirado) e\n< Representa o Rear(Posi��o do proximo elemento a ser adicionado)\n";
    for(int i=0;i<n;++i){
        if(i==fila.Front){
        std::cout<<">"<<fila.Arr[i]<<"| "<<(i+1)<<"\n";
        ++i;
        }
        if(i==fila.Rear){
        std::cout<<"<"<<fila.Arr[i]<<"| "<<(i+1)<<"\n";
        ++i;
        }
        else{
        std::cout<<" "<<fila.Arr[i]<<"| "<<(i+1)<<"\n";
    }
}
        std::cout<<"Front:"<<fila.Front<<"\n";
        std::cout<<"Rear:"<<fila.Rear<<"\n";
        std::cout<<"Count:"<<fila.Count<<"\n";

}
void PrintFrontCountSize(Queue& F1){
char Frente = Front(F1);
 if (Frente == '\0')
 std::cout << "Frente: Fila vazia.\n";
 else
 std::cout << "Frente: " << Frente << '\n';
 std::cout << "Elementos na fila: " << Count(F1) << '/' << Size(F1)
 << ", a fila " << (IsEmpty(F1) ? "est� vazia" : "cont�m elementos") << ".\n";
}

void Comands(){//apenas da o print dos comandos para a tabela de comandos utilizada para testar as fun��es e criar as proprias filas.
    std::cout<<"\nTabela de comandos\n";
    std::cout<<"-1=refazer o codigo teste\n0=Comandos\n1=Print\n2=Enqueue\n3=Dequeue\n4=Front\n5=Size\n6=Count\n7=IsEmpty\n8=Clear\n9=Creditos\n10= Finalizar o Programa \n\n";
}

void Credits(){//imprime quem fez o trabalho,matricula,turma, materia e professor.
    for(int i=0;i<2;++i){
            std::cout<<"\n";
        }
    std::cout<<"Lucas Iudi Corregliano Gallinari\n" <<"M�tricula: 32138628\n"<<"Turma 3G\n" << "Materia: Estrutura de Dados I \n" <<"Professor: Andr� Kishimoto\n";
    for(int i=0;i<2;++i){
            std::cout<<"\n";
        }
}


#endif // VETORCH_H_INCLUDED
