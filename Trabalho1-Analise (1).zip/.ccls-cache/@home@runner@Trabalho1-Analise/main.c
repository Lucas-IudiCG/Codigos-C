//Nome: Lucas Iudi Corregliano Gallinari
//TIA:32138628
//Nome: Thiago Aidar Figueiredo
//TIA: 32144547
//Nome: Yiou Wu
//TIA: 32123213
//Projeto tape.dvi
#include <stdio.h>
#include <stdlib.h>

int* leitura(int* time, int* qntmusic){
  FILE  *textfile;
  char  *text;
  int min, seg, i = 0;
  textfile = fopen("tape.in", "r");
  if(textfile == NULL){
    printf("Erro abrindo o arq: tape.in");
    exit(1);
  }
  fscanf(textfile, "%d\t%d", time, qntmusic);
  printf("Time: %d\nQnt: %d\n",*time,*qntmusic);
  int* music = malloc(*qntmusic*sizeof(int));
  while(i<=*qntmusic){
    fscanf(textfile, "%d\t%d", &min, &seg);
    music[i++] = min*60 + seg;
  }
    
  fclose(textfile);
  return music;
}

void troca(int *vet, int i, int j){
	int aux = vet[i];
	vet[i] = vet[j];
	vet[j] = aux;
}

int soma(int *vet,int inicio, int fim){
  int soma = 0;
  for(int i = inicio; i<fim;i++){
    soma = soma + vet[i];
  }
  return soma;
}

int compara(int* vet, int n, int time){
  int somaA, somaB;
  for(int i=1; i<n-1; i++){
    if (soma(vet, 0, i)<time && soma(vet,i, n) < time)
      return i;
  }
  return -1;
}
int permuta(int *vet, int i, int n, int time){
	if(i == n){
    int result = compara(vet,n,time);
    if(result!= -1)
      return result;    
  }else{
		for(int j = i; j < n; j++){
			troca(vet, i, j);
			int recebe = permuta(vet, i + 1, n, time);
      if (recebe != -1) return recebe;
			troca(vet, i, j);
		}
	}
}


int main(){
  int time, qntmusic, soma = 0, result;
  int * listamusicas = leitura(&time,&qntmusic);
  for (int i = 0 ; i < qntmusic;i++){
    soma += listamusicas[i];
  }
  if(soma < time*60){
    result = permuta(listamusicas,0, qntmusic, time*60/2);
    printf("Result: %d\n",result);
    if (result != -1) {
      printf("Músicas alocadas com sucesso");
      printf("\nLado A:\n");
      for(int i = 0; i<result;i++){
        int min = listamusicas[i] / 60;
        printf("%d min %d seg\n", min, listamusicas[i]-min*60);
      }
      printf("\nLado B:\n");
      for(int i = result; i< qntmusic;i++){
        int min = listamusicas[i] / 60;
        printf("%d min %d seg\n", min, listamusicas[i]-min*60);
      }
    }
    else printf("Não foi possível alocar as músicas");

  }else printf("Tempo das fitas não é suficiente");

  return 0;
}