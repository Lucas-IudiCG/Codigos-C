#include <iostream>

using namespace std;
double* teste(double* v, int m, double k){
int j;
for (j=0; j<m; j++)
	if(*(v+j) == k) return v+j;
	return 0;
}

int main(){
	double w[15], x, *z;
	void *r;
	w[0]=12.;
	w[1]=10.;
	
	r = teste(w, 10, 12.);
	cout<<r<<endl;
	cout << (*teste(w, 15, 10.))<<endl;
	z = teste(w, 15, 10.);
	cout<<z<<endl;
	return 0;
}