#include <iostream>

using namespace std;

int *enderecoMenorVet(int *array, int n){
	int *P=array;
	int *Menor;
	Menor=P;
	for (int j=0;j<n;j++){
	if (*(P+j)<*Menor){
		Menor=(P+j);
	}
}
	return Menor;
}


int main(){
	int a[15]={24,14,13,22,26,87,42,73,99,54,67,64,35,1,49};
	cout<<"Dado um vetor com 15 elementos: "<<endl;
	int *Result= enderecoMenorVet(a,15);
	cout<<"o EndereÃ§o de Memoria: "<<Result<<"de o elemento eÂ´: "<<*Result <<endl;
	return 0;
}