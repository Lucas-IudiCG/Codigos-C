#include <iostream>

using namespace std;

int verificar(int A,int vet[],int n){
for(int j = 0; j < n; j++){
    if(A == vet[j]){
        return 1;
    }
}
 return 0;
}

int *uniao(int *v1, int nV1, int *v2, int nV2, int qtde){
	int v3[qtde];
	int j=0;
	for(int i = 0 ; i < nV2 ; i++){
	    if(verificar(*(v2+i),v1,5)){
	       v3[j]=*(v2+i);
	       j++;
	    }
	}
	for(int i = 0 ; i < qtde ; i++){
		cout<<"["<<*(v3+i)<<"],";
	}
	
	
	return v3;
}

int main()
{
int v1[5]={1,2,3,4,5};
int v2[5]={1,3,5,7,8};
int i;
int c=0;
for(i = 0 ; i < 5 ; i++){
    if(verificar(v2[i],v1,5)){
       c++;
    }
}
int *P1=v1;
int *P2=v2;
int *result =new int[c];
result=uniao(P1,5,P2,5,c);
delete[] result;
result=nullptr;
return 0;
}