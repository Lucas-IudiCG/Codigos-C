#include <iostream>

using namespace std;

bool verificar(int *aux, int val,int n){
    for(int i=0;i<n;i++){
        if(*(aux+i)==val){
            return false;
        }
    }
    return true;
}

int main()
{
    int Vaux[100], tamanho=0, variavel;
    bool program=true;
    bool verificacao=true;
    while(program){
        bool verificacao=true;
        while(verificacao){
            cout<<"digite o proximo elemento: ";
            cin>>variavel;
            verificacao=false;
            if(variavel>1000){
                cout<<"Invalido"<<endl;
                verificacao=true;
            }
        }
            ++tamanho;
            int *vet=new int[tamanho];
            if(verificar(Vaux,variavel,tamanho)){
                cout<<"Elemento aceito"<<endl;
                Vaux[tamanho-1]=variavel;
                for(int i =0;i<tamanho;i++){
                    *(vet+i)=*(Vaux+i);
                }
            }
            else{
                cout<<"Elemento rejeitado"<<endl;
                tamanho--;
                for(int i =0;i<tamanho;i++){
                    *(vet+i)=*(Vaux+i);
                }
            }
            int continuar=0;
            verificacao=true;
            while(verificacao){
                cout<<"Você deseja parar o programa sim(1), não (0): ";
                cin>>continuar;
                if(continuar==1){
                    for(int i =0;i<tamanho;i++){
                        cout<<*(vet+i)<<"|";
            }
                    cout<<"\nPrograma Finalizado";
                    verificacao=false;
                    program=false;
            }
                else if(0>continuar>1){
                    cout<<"codigo invalido"<<endl;
                }
                else if(continuar==0){
                  for(int i =0;i<tamanho;i++){
                        cout<<*(vet+i)<<"|";
                  }
                  cout<<endl;
                  verificacao=false;  
                }
                }
            delete[] vet;
            vet=nullptr;
            
        
        
    }
    

    return 0;
}