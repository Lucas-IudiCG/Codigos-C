#include <iostream>

using namespace std;

int *busca(int *a, int n, int val){
	int *P=a;
	for (int j=0;j<n;j++){
	if (*(P+j)==val){
		cout<<j+1<<"|"<<(P+j)<<endl;
		return (P+j);
	}
}
	cout<<"Não tem"<<endl;
	return nullptr;

}


int main(){
	int a[15]={24,14,13,22,26,87,42,73,99,54,67,64,35,1,49},val;
	cout<<"Dado um vetor com 15 elementos: "<<endl;
	cout<<"Digite o Valor a ser procurado: ";
	cin>>val;
	int *Result= busca(a,15,val);
	cout<<"o Endereço de Memoria: "<<Result<<endl;
	return 0;


}