#include <iostream>
#include "StackH.h"

//Lucas Iudi Corregliano Gallinari
//M�tricula: 32138628
//Turma 3G
//"Materia: Estrutura de Dados I
//"Professor: Andr� Kishimoto

int main() {
    setlocale(LC_CTYPE,"Portuguese");//define o idioma para portugues
    Stack S1 =Create();//cria a estrutura Stack, chamada S1
    PrintTopCountSize(S1);
    char nada;
    std::cout << "--------------------\n";
    std::cout<<"Digite qualquer character para iniciar os processos de Push: ";//usei esse std::cin, apenas para demorar e para voc~e e eu poder conferir o que foi printado por etapas
    std::cin>>nada;

     std::cout << "--------------------\n";
     std::string str = "Hello, World!";//quebra a string hello world e coloca seus respectivos elementos ao long da pilha
     for (int i = 0; i < str.length(); ++i)
     {
     Push(S1, str[i]);
     PrintTopCountSize(S1);
     }
     std::cout << "--------------------\n";
    std::cout<<"Digite qualquer character para iniciar os processos de Pop: ";//usei esse std::cin, apenas para demorar e para voc~e e eu poder conferir o que foi printado por etapas
    std::cin>>nada;
     std::cout << "--------------------\n";
     char top;
     while (!IsEmpty(S1))//vai retirando os elementos da pilha que foram colocados 1 a 1.
     {
     top = Pop(S1);
     std::cout << "Pop retornou: " << top << '\n';
     PrintTopCountSize(S1);
     }
     std::cout << "--------------------\n";//adiciona de novo o ultimo elemento da string, no caso "!"
     for (const char& c : str)
     Push(S1, c);
     PrintTopCountSize(S1);

     std::cout << "--------------------\n";//da um clear direto.
     Clear(S1);
     PrintTopCountSize(S1);

    std::cout << "--------------------\n";
    std::cout<<"Digite qualquer character para iniciar a Tabela de Comandos: ";//usei esse std::cin, para separar a primeira parte do codigo da segunda.
    std::cin>>nada;
    Credits();//come�a a tabela de comando feita para testar as fun��es.
    bool Menu= false;
    char valor;
    Comands();
    while(Menu==false){
        int Comando;
        std::cout<<"\n";
        std::cout<<"Comando: ";
        std::cin>>Comando;

        if(Comando==0){//se comando = 0, os comandos s�o impridos denovo.
                Comands();
    }
        if(Comando==1){//se comando = 1, � printado todos os elementos da pilha
                Print(S1);
    }
        if(Comando==2){//se comando = 2,adiciona um elemento na pilha
                std::cout<<"Elemento a ser adiacionado: ";
                std::cin >>valor;
                Push(S1,valor);
        }
        if(Comando==3){//se comando = 3,retira um elemento da pilha
                char y=Pop(S1);
                std::cout<<"Elemento Retornado: "<<y<<"\n";
        }
        if(Comando==4){//se comando = 4,imprime o topo junto com a capacidade da pilha
                PrintTopCountSize(S1);

        }
        if(Comando==5){//se comando = 5,retorna ainda quantos elementos podem ser adicionados
                int Cap=Size(S1);
                int Tam=Count(S1);
                std::cout<<"A pilha tem capacidade: "<<Cap-Tam<<"\n";
        }
        if(Comando==6){//se comando = 6, quantos elementos est�o na pilha
                int Tam=Count(S1);
                std::cout<<"A pilha tem "<<Tam<<" Elementos\n";
    }
        if(Comando==7){//se comando = 7, retorna um variavel bool, que confirma se est� vazia ou n�o
                bool vazio=IsEmpty(S1);
                if (vazio==true){
                    std::cout<<"Pilha vazia \n";
                }
                if(vazio==false){
                    std::cout<<"Pilha n�o vazia \n";
                }
    }
        if(Comando==8){//se comando = 8,Esvazia a pilha
                Clear(S1);
                std::cout<<"Esvaziado \n";
    }
        if(Comando==9){//se comando = 9,imprime os creditos
            Credits();
    }
        if(Comando==10){//se comando = 10,o menu vira true,tirando do loop,finalizando o programa
            Menu=true;
            std::cout<<"Programa Finalizado";
    }
        if(Comando==-1){//se comando = -1,ele repete o teste do codigo
            PrintTopCountSize(S1);
        char nada;
        std::cout << "--------------------\n";
        std::cout<<"Digite qualquer character para iniciar os processos de Push: ";
        std::cin>>nada;

         std::cout << "--------------------\n";
         std::string str = "Hello, World!";
         for (int i = 0; i < str.length(); ++i)
         {
         Push(S1, str[i]);
         PrintTopCountSize(S1);
         }
         std::cout << "--------------------\n";
        std::cout<<"Digite qualquer character para iniciar os processos de Pop: ";
        std::cin>>nada;
         std::cout << "--------------------\n";
         char top;
         while (!IsEmpty(S1))
         {
         top = Pop(S1);
         std::cout << "Pop retornou: " << top << '\n';
         PrintTopCountSize(S1);
         }
         std::cout << "--------------------\n";
         for (const char& c : str)
         Push(S1, c);
         PrintTopCountSize(S1);

         std::cout << "--------------------\n";
         Clear(S1);
         PrintTopCountSize(S1);

        std::cout << "--------------------\n";
        }
    Top(S1);
}
}
